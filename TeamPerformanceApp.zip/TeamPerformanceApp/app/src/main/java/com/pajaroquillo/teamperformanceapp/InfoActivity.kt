package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/


import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_myinfo.*

class InfoActivity : AppCompatActivity()  {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_myinfo)
        ponerValores()
    }
    /*
    Buscar y poner los valores de la información del usuario conectado en la base de datos SQLITE
     */
    fun ponerValores(){
        var txtNombre = findViewById<TextView>(R.id.textname)
        var txtRole = findViewById<TextView>(R.id.textrole)
        var txtmail = findViewById<TextView>(R.id.textmail)
        var txtaddr = findViewById<TextView>(R.id.textaddress)
        var imgenusu = findViewById<ImageView>(R.id.imageusu)
        val userDatabase = DataBaseHelper(this)
        val usuario = userDatabase.readUser(usuarioConectado.USUARIO_CONECTADO)
        txtNombre.text = usuario.get(0).name
        txtRole.text=usuario.get(0).role
        txtmail.text=usuario.get(0).mail
        txtaddr.text = usuario.get(0).address
        var idimg : Int
        idimg = resources.getIdentifier("com.pajaroquillo.teamperformanceapp:drawable/"+ usuario.get(0).imagen, null,null)
        imgenusu.setImageResource(idimg)
    }
}