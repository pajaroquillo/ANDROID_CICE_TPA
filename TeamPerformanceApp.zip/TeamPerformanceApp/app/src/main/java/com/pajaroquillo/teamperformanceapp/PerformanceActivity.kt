package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.support.v7.app.AppCompatActivity
import android.support.v7.graphics.Palette
import android.transition.Transition
import android.widget.*
import kotlinx.android.synthetic.main.activity_performance.*


class PerformanceActivity : AppCompatActivity()  {

    companion object {
        val EXTRA_PARAM_ID = "postion_id"

        fun newIntent(context: Context, position: Int): Intent {
            val intent = Intent(context,PerformanceActivity::class.java)
            intent.putExtra(EXTRA_PARAM_ID, position)
            return intent
        }
    }

    lateinit private var userdb: UserDB

    private var defaultColor: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_performance)
        ponerValores()

        windowTransition()
        getPhoto()
    }
    /*
    Función que busca en la base de datos al usuario, pone sus datos en el layout y permite marcar y actualizar la valoración del compañero.
     */
    fun ponerValores(){
        var txtNombre = findViewById<TextView>(R.id.textName3)
        var txtRole = findViewById<TextView>(R.id.textrole3)
        var imagePer2 = findViewById<ImageView>(R.id.imagePer3)
        val userDatabase = DataBaseHelper(this)
        userdb = userDatabase.teamList()[intent.getIntExtra(EXTRA_PARAM_ID,0)]
        txtNombre.text = userdb.name
        txtRole.text = userdb.role

        var idimg : Int
        idimg = resources.getIdentifier("com.pajaroquillo.teamperformanceapp:drawable/"+ userdb.imagen, null,null)
        imagePer2.setImageResource(idimg)

        var puntuacion = findViewById<RatingBar>(R.id.ratingBar)
        puntuacion.setOnRatingBarChangeListener({ ratingBar: RatingBar, fl: Float, b: Boolean ->
            pintarPorentaje(puntuacion.rating.toInt())
        })

        var btnsend = findViewById<Button>(R.id.btn_send)
        btnsend.setOnClickListener ({
            userDatabase.updatePoints(usuarioConectado.USUARIO_CONECTADO,userdb.userid, puntuacion.rating.toInt())
            Toast.makeText(this@PerformanceActivity,"Se ha actualizado la evaluacion del usuario a " + puntuacion.rating.toInt() + ", se cerrara la pantalla", Toast.LENGTH_SHORT).show()
            val handler = Handler()
            val runnable = object : Runnable {
                override fun run() {
                    handler.postDelayed(this, 250)
                }
            }
            finish()
        })

    }
    /*
    Función que pinta el circulo de porcentaje de puntos
     */
    fun pintarPorentaje(valor: Int) {
        var i = 1
        val handler = Handler()
        val runnable = object : Runnable {
            override fun run() {
                if (i <= (20*valor)) {
                    handler.postDelayed(this, 2)
                    circularView.setValue(i, valor)
                    i++
                }
            }
        }
        handler.post(runnable)
    }


    private fun windowTransition() {
        window.enterTransition.addListener(object: Transition.TransitionListener{
            override fun onTransitionEnd(p0: Transition?){
                window.enterTransition.removeListener(this)
            }
            override fun onTransitionCancel(p0: Transition?) {}
            override fun onTransitionPause(p0: Transition?) {}
            override fun onTransitionResume(p0: Transition?) {}
            override fun onTransitionStart(p0: Transition?) {}
        })
    }

    private fun getPhoto() {
        val photo = BitmapFactory.decodeResource(resources, userdb.getImageResourceId(this))
        colorize(photo)
    }

    private fun colorize(photo: Bitmap) {
        val palette = Palette.from(photo).generate()
        applyPalette(palette)
    }

    private fun applyPalette(palette: Palette) {
        window.setBackgroundDrawable(ColorDrawable(palette.getDarkMutedColor(defaultColor)))
    }

}