package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.app.ActivityOptionsCompat
import android.support.v4.util.Pair
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.StaggeredGridLayoutManager
import android.view.View
import android.widget.AdapterView
import kotlinx.android.synthetic.main.activity_team.*
import kotlinx.android.synthetic.main.row_team.*

class TeamActivity: AppCompatActivity()  {
    lateinit var staggeredLayoutManager: StaggeredGridLayoutManager
    lateinit var adapter: TeamListAdapter
    private var isListView: Boolean = false

    private val onItemClickListener = object : TeamListAdapter.OnItemClickListener{
        override fun onItemClick(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
            val intent = PerformanceActivity.newIntent(this@TeamActivity,p2)

            //emparejamos las vistas entre el activitya y el ativityb
            val imagePair = Pair.create(teamImage_1 as View, "tImageUSU")
            //creamos la transición de una a otra
            val opciones = ActivityOptionsCompat.makeSceneTransitionAnimation(this@TeamActivity, imagePair)
            ActivityCompat.startActivity(this@TeamActivity, intent, opciones.toBundle())
        }


    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_team)

        isListView = true
        staggeredLayoutManager= StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL)
        listteam.layoutManager = staggeredLayoutManager

        adapter = TeamListAdapter(this)
        listteam.adapter = adapter

        adapter.setOnItemClickListener(onItemClickListener)

    }

}