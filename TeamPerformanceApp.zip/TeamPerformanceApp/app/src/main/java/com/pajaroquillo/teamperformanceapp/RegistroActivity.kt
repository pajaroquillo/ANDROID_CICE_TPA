package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/
import android.support.v7.app.AppCompatActivity

import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import android.widget.ProgressBar
import android.widget.EditText
import android.content.Intent
import android.widget.Toast
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Button


class RegistroActivity : AppCompatActivity()  {

    //Progres Bar
    private val progressBar: ProgressBar? = null

    //Firebase
    private var mAuth: FirebaseAuth? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
        //progressbar
        val progressBar = findViewById<ProgressBar>(R.id.progressbar)

        mAuth = FirebaseAuth.getInstance()

        //Botones
        val btnSignin = findViewById<Button>(R.id.btn_sign_in)
        btnSignin.setOnClickListener{(registerUser())}
        val btnExit = findViewById<Button>(R.id.btn_back)
        btnExit.setOnClickListener{(finish())}
    }

    fun registerUser() {

        //Campos de datos
        val inputEmail = findViewById<EditText>(R.id.email);
        val inputPassword = findViewById<EditText>(R.id.password);
        val inputName = findViewById<EditText>(R.id.name);
        val inputRole = findViewById<EditText>(R.id.role);
        val inputDir = findViewById<EditText>(R.id.dir);

        val email = inputEmail?.getText().toString().trim()
        val password = inputPassword?.getText().toString().trim()
        val nombre = inputName?.getText().toString().trim()
        val role = inputRole?.getText().toString().trim()
        val direccion = inputDir?.getText().toString().trim()

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Introduce un email", Toast.LENGTH_SHORT).show()
            return
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Introduce una Contraseña", Toast.LENGTH_SHORT).show()
            return
        }
        if (TextUtils.isEmpty(nombre)) {
            Toast.makeText(this, "Introduce un nombre", Toast.LENGTH_SHORT).show()
            return
        }
        if (TextUtils.isEmpty(role)) {
            Toast.makeText(this, "Introduce tu rol en la empresa", Toast.LENGTH_SHORT).show()
            return
        }
        if (TextUtils.isEmpty(direccion)) {
            Toast.makeText(this, "Introduce un dirección postal", Toast.LENGTH_SHORT).show()
            return
        }
        if (password.length < 6) {
            Toast.makeText(this, "Contraseña muy corta", Toast.LENGTH_SHORT).show()
            return
        }
        progressBar?.setVisibility(View.VISIBLE)

        //Creamos el usuario en Firebase
        mAuth?.createUserWithEmailAndPassword(email, password)!!.addOnCompleteListener(this) { task ->
                    Log.d("TAG", "createUserWithEmail:onComplete:" + task.isSuccessful)
                    progressBar?.setVisibility(View.GONE)
                    if (!task.isSuccessful) {
                        val error = task.exception!!.toString()
                        Toast.makeText(this@RegistroActivity, error,
                                Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@RegistroActivity, "usuario creado", Toast.LENGTH_LONG).show()
                        //Logueamos al usuario
                        val userDatabase = DataBaseHelper(this)
                        val userid = userDatabase.addUser(nombre,role,email,direccion)

                        userDatabase.addPerformanceTotal(userid)

                        usuarioConectado.USUARIO_CONECTADO = userDatabase.readUserByMail(email)
                        val intent = Intent(this@RegistroActivity, PrincipalActivity::class.java)
                        startActivity(intent)
                    }
                }
    }

}