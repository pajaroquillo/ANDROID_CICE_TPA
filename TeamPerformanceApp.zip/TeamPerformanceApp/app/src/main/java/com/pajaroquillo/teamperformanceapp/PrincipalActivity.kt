package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.support.v7.graphics.Palette
import android.widget.Button
import android.widget.ImageView

class PrincipalActivity : AppCompatActivity()  {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)

        //Botones
        val btnMyInfo = findViewById<Button>(R.id.btn_my_info)
        btnMyInfo.setOnClickListener{(openActivity(1))}
        val btnMyTeam = findViewById<Button>(R.id.btn_my_team)
        btnMyTeam.setOnClickListener{(openActivity(2))}
        val btnMyPerformance = findViewById<Button>(R.id.btn_my_performance)
        btnMyPerformance.setOnClickListener{(openActivity(3))}
        val btnExit = findViewById<Button>(R.id.btn_exit)
        btnExit.setOnClickListener{(cerrarApp())}
        //lo mismo sobre las imagenes
        val btnMyInfoImg = findViewById<ImageView>(R.id.imageMInfo)
        btnMyInfoImg.setOnClickListener{(openActivity(1))}
        val btnMyTeamImg = findViewById<ImageView>(R.id.imageMTeam)
        btnMyTeamImg.setOnClickListener{(openActivity(2))}
        val btnMyPerformanceImg = findViewById<ImageView>(R.id.imageMPerformance)
        btnMyPerformanceImg.setOnClickListener{(openActivity(3))}
        val btnExitImg = findViewById<ImageView>(R.id.imageMExit)
        btnExitImg.setOnClickListener{(cerrarApp())}
    }
    /*
    Función que cierra la APP
     */
    private fun cerrarApp(){
        val closeInt = Intent(applicationContext, MainActivity::class.java)
        closeInt.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        closeInt.putExtra("CloseApp", true)
        startActivity(closeInt)
    }
    /*
    Función que abre las distintas opciones segun el boton pulsado.
     */
    private fun openActivity(activity: Int){

        if (activity == 1){
            val intent = Intent(this@PrincipalActivity, InfoActivity::class.java)
            startActivity(intent)
        }else{
            if (activity ==2){
                val intent = Intent(this@PrincipalActivity, TeamActivity::class.java)
                startActivity(intent)
            }else{
                if (activity ==3){
                    val intent = Intent(this@PrincipalActivity, MyPerformanceActivity::class.java)
                    startActivity(intent)
                }
            }
        }

    }
}