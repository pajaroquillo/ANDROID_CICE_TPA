package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

import android.content.Context
import android.graphics.BitmapFactory
import android.support.v4.content.ContextCompat
import android.support.v7.graphics.Palette
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.row_team.view.*

class TeamListAdapter (private var context: Context): RecyclerView.Adapter<TeamListAdapter.ViewHolder>() {

    lateinit var itemClickListener: AdapterView.OnItemClickListener

    override fun getItemCount(): Int {
        val db = DataBaseHelper(context)

        return db.teamList().size
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int):ViewHolder {
        val itemView = LayoutInflater.from(parent?.context).inflate(R.layout.row_team,parent,false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        val db = DataBaseHelper(context)
        val user = db.teamList()[position]
            holder?.itemView?.teamName?.text = user.name
            holder?.itemView?.teamUserId?.text = user.userid

            Picasso.with(context).load(user.getImageResourceId(context)).into(holder?.itemView?.teamImage_1)

            val photo = BitmapFactory.decodeResource(context.resources, user.getImageResourceId(context))
            Palette.from(photo).generate { palette ->
                val bgColor = palette.getDarkVibrantColor(ContextCompat.getColor(context,android.R.color.holo_blue_light)) //.getMutedColor
                holder?.itemView?.teamNameHolder?.setBackgroundColor(bgColor)
            }
    }

    fun setOnItemClickListener(itemClickListener: TeamListAdapter.OnItemClickListener){
        this.itemClickListener = itemClickListener
    }

    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView), View.OnClickListener{
        init{
            itemView.teamHolder.setOnClickListener(this)
        }

        override fun onClick(p0: View?) {
            itemClickListener.onItemClick(null,p0, adapterPosition,0 )
        }
    }

    interface OnItemClickListener : AdapterView.OnItemClickListener {
        override fun onItemClick(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

        }
    }
}

