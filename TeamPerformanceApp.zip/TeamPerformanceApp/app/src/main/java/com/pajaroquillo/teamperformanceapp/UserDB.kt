package com.pajaroquillo.teamperformanceapp

import android.content.Context

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

class UserDB(val userid: String, val name: String, val mail: String, val address: String, val role:String, val imagen: String){
    fun getImageResourceId(context: Context): Int {
        return context.resources.getIdentifier(this.imagen, "drawable", context.packageName)
    }
}


