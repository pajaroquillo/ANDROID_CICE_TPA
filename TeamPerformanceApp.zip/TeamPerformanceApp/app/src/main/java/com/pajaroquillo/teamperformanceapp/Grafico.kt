package com.pajaroquillo.teamperformanceapp


/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.pajaroquillo.teamperformanceapp.R.color.*

class GraficoCircular(context: Context?, attrs: AttributeSet?) : View(context, attrs) {

    private val rectF = RectF()
    private val paint = Paint().apply {
        style = Paint.Style.STROKE
    }

    private var valor = 0
    private var percentage=0

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

        canvas?.let {
            rectF.apply {
                val width = (it.width.div(2)).toFloat()
                val height = (it.height.div(2)).toFloat()
                set(width - 200, height - 200, width + 200, height + 200)
            }
            when(valor){
                1 -> {
                    pintarBlanco(it)
                    val fillPercentage = (360 * (percentage / 100.0)).toFloat()
                    pintarColorfijo(it,270f,fillPercentage,getResources().getColor(un_punto))
                }
                2 ->{
                    pintarBlanco(it)
                    val fillPercentage = (360 * (percentage / 100.0)).toFloat()
                    if (fillPercentage<=72f) {
                        pintarColorfijo(it,270f,fillPercentage,getResources().getColor(un_punto))
                    }else {
                        pintarColorfijo(it,270f,72f,getResources().getColor(un_punto))
                        pintarColorfijo(it,342f,fillPercentage-72f,getResources().getColor(dos_puntos))
                    }
                }
                3 ->{
                    pintarBlanco(it)
                    val fillPercentage = (360 * (percentage / 100.0)).toFloat()
                    if (fillPercentage<=72f) {
                        pintarColorfijo(it,270f,fillPercentage,getResources().getColor(un_punto))
                    }else {
                        if (fillPercentage<=144f) {
                            pintarColorfijo(it, 270f, 72f, getResources().getColor(un_punto))
                            pintarColorfijo(it,342f,fillPercentage-72f,getResources().getColor(dos_puntos))
                        }else{
                            pintarColorfijo(it,270f,72f,getResources().getColor(un_punto))
                            pintarColorfijo(it,342f,72f,getResources().getColor(dos_puntos))
                            pintarColorfijo(it,54f,fillPercentage-144f,getResources().getColor(tres_puntos))
                        }
                    }
                }
                4 -> {
                    pintarBlanco(it)
                    val fillPercentage = (360 * (percentage / 100.0)).toFloat()
                    if (fillPercentage<=72f) {
                        pintarColorfijo(it,270f,fillPercentage,getResources().getColor(un_punto))
                    }else {
                        if (fillPercentage<=144f) {
                            pintarColorfijo(it, 270f, 72f, getResources().getColor(un_punto))
                            pintarColorfijo(it,342f,fillPercentage-72f,getResources().getColor(dos_puntos))
                        }else {
                            if (fillPercentage <= 216f){
                                pintarColorfijo(it,270f,72f,getResources().getColor(un_punto))
                                pintarColorfijo(it,342f,72f,getResources().getColor(dos_puntos))
                                pintarColorfijo(it,54f,fillPercentage-144f,getResources().getColor(tres_puntos))
                            }else{
                                pintarColorfijo(it, 270f, 72f, getResources().getColor(un_punto))
                                pintarColorfijo(it, 342f, 72f, getResources().getColor(dos_puntos))
                                pintarColorfijo(it, 54f, 72f, getResources().getColor(tres_puntos))
                                pintarColorfijo(it, 126f, fillPercentage-216f, getResources().getColor(cuatro_puntos))
                            }
                        }
                    }
                }
                5 ->{
                    pintarBlanco(it)
                    val fillPercentage = (360 * (percentage / 100.0)).toFloat()
                    if (fillPercentage<=72f) {
                        pintarColorfijo(it,270f,fillPercentage,getResources().getColor(un_punto))
                    }else {
                        if (fillPercentage<=144f) {
                            pintarColorfijo(it, 270f, 72f, getResources().getColor(un_punto))
                            pintarColorfijo(it,342f,fillPercentage-72f,getResources().getColor(dos_puntos))
                        }else {
                            if (fillPercentage <= 216f){
                                pintarColorfijo(it,270f,72f,getResources().getColor(un_punto))
                                pintarColorfijo(it,342f,72f,getResources().getColor(dos_puntos))
                                pintarColorfijo(it,54f,fillPercentage-144f,getResources().getColor(tres_puntos))
                            }else{
                                if (fillPercentage<=288f) {
                                    pintarColorfijo(it, 270f, 72f, getResources().getColor(un_punto))
                                    pintarColorfijo(it, 342f, 72f, getResources().getColor(dos_puntos))
                                    pintarColorfijo(it, 54f, 72f, getResources().getColor(tres_puntos))
                                    pintarColorfijo(it, 126f, fillPercentage-216f, getResources().getColor(cuatro_puntos))
                                }else{
                                    pintarColorfijo(it, 270f, 72f, getResources().getColor(un_punto))
                                    pintarColorfijo(it, 342f, 72f, getResources().getColor(dos_puntos))
                                    pintarColorfijo(it, 54f, 72f, getResources().getColor(tres_puntos))
                                    pintarColorfijo(it, 126f, 72f, getResources().getColor(cuatro_puntos))
                                    pintarColorfijo(it, 198f, fillPercentage-288f, getResources().getColor(cinco_puntos))
                                }
                            }
                        }
                    }
                }
                else -> {
                    pintarBlanco(it)
                }
            }

        }
    }
    //pintar el circulo de blanco
    fun pintarBlanco(canvas: Canvas?){
        canvas?.drawArc(rectF, 0f, 360f, false, paint.apply {
            color = getResources().getColor(colorAccent)
            strokeWidth = 90f
        })
    }
    //pintar lo que corresponda (angle) del color que se quiere
    fun pintarColorfijo(canvas: Canvas?, start: Float, angle: Float, valorcolor: Int){
        canvas?.drawArc(rectF, start, angle, false, paint.apply {
            color =  valorcolor
            strokeWidth = 60f
        })
    }
    //dar valores a porcentage y valor
    fun setValue(percentage: Int, valor: Int) {
        this.percentage = percentage
        this.valor = valor
        invalidate()
    }
}
