package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

import android.provider.BaseColumns

object DataB {

    //clase que contiene el formato de tabla de usuarios
    class UserEntry : BaseColumns {
        companion object {
            const val TABLE_NAME = "users"
            const val  COLUMN_USER_ID = "userid"
            const val  COLUMN_NAME = "name"
            const val  COLUMN_MAIL = "mail"
            const val  COLUMN_DIR = "dir"
            const val  COLUMN_ROLE = "role"
            const val  COLUMN_IMG = "imagen"

        }
    }
    //clase que contiene el formato de tabla de evaluaciones
    class UserPerformance : BaseColumns{
        companion object {
            const val  TABLE_NAME = "performance"
            const val  COLUMN_USERID = "usereid"
            const val  COLUMN_USEREVA = "usereva"
            const val  COLUMN_EVA = "eval"
        }
    }
}