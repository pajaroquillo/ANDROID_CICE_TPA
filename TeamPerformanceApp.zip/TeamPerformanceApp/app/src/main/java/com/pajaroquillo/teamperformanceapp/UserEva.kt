package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

class UserEva(val userid: String, val userEva: String, var eva: Int)