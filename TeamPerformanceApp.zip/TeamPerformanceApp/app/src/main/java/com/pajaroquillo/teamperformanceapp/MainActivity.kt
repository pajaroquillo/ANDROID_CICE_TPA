package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.firebase.auth.FirebaseAuth
import android.widget.ProgressBar
import android.widget.EditText
import android.widget.Toast
import android.text.TextUtils
import android.util.Log
import android.view.View


class MainActivity : AppCompatActivity() {



    //Campos de datos
    private val inputEmail: EditText? = null
    private val inputPassword: EditText? = null

    //Progres Bar
    private val progressBar: ProgressBar? = null

    //Firebase
    private var mAuth: FirebaseAuth? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if(getIntent().getExtras() != null && getIntent().getExtras().getBoolean("CloseApp", false)) {
            finish();
        }

        val progressBar = findViewById<ProgressBar>(R.id.progressbar)

        mAuth = FirebaseAuth.getInstance()

        //Botones
        val btnSignin = findViewById<Button>(R.id.btn_sign_in)
        btnSignin.setOnClickListener{(login())}
        val btnExit = findViewById<Button>(R.id.btn_back)
        btnExit.setOnClickListener{(cerrarApp())}
        val btnRegistrar = findViewById<Button>(R.id.btn_register)
        btnRegistrar.setOnClickListener{(abrirRegistro())}
        val btnReset = findViewById<Button>(R.id.btn_reset)
        btnReset.setOnClickListener{(resetPasswordPressed())}
    }
    /*
    Función para abrir el layout de registro en la aplicacion de firebase si no existe el usuario.
     */
    fun abrirRegistro(){
        val intent = Intent(this@MainActivity, RegistroActivity::class.java)//GeneralActivity.class);
        startActivity(intent)
    }
    /*
    Función que cierra la APP
     */
    fun cerrarApp(){
        finish()
    }

    /*
    Funcíon que hace el logín de usuario
     */
    fun login() {
        val inputEmail = findViewById<EditText>(R.id.email);
        val inputPassword = findViewById<EditText>(R.id.password);
        val email = inputEmail?.getText().toString().trim()
        val password = inputPassword?.getText().toString().trim()

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, R.string.mail_vacio, Toast.LENGTH_SHORT).show()
            return
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, R.string.pwd_vacio, Toast.LENGTH_SHORT).show()
            return
        }

        if (password.length < 6) {
            Toast.makeText(this, R.string.pwd_longitud, Toast.LENGTH_SHORT).show()
            return
        }
        progressBar?.setVisibility(View.VISIBLE)

        mAuth?.signInWithEmailAndPassword(email, password)!!.addOnCompleteListener(this) { task ->
            Log.d("TAG", "Conectado a FIREBASE: signInWithEmail:onComplete:" + task.isSuccessful)

            if (!task.isSuccessful) {
                val error = task.exception!!.toString()
                Log.w("TAG", "Error en FIREBASE: signInWithEmail:failed", task.exception)
                Toast.makeText(this@MainActivity, R.string.auth_failed,
                        Toast.LENGTH_SHORT).show()

            } else {
                //Logueamos al usuario
                val userDatabase = DataBaseHelper(this)
                usuarioConectado.USUARIO_CONECTADO = userDatabase.readUserByMail(email)
                val intent = Intent(this@MainActivity, PrincipalActivity::class.java)//GeneralActivity.class);
                startActivity(intent)
            }
        }
    }
    /*
    Función para enviar el email de olvido de contraseña de Firebase
     */
    fun resetPasswordPressed() {
        val inputEmail = findViewById<EditText>(R.id.email);
        val email = inputEmail?.getText().toString().trim()
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, R.string.no_mail, Toast.LENGTH_SHORT).show()
            return
        }
        progressBar?.setVisibility(View.VISIBLE)
        mAuth?.sendPasswordResetEmail(email)?.addOnCompleteListener( { task ->
            if (task.isSuccessful) {
                Toast.makeText(this@MainActivity, R.string.reset_pwd, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, R.string.reset_pwd_error, Toast.LENGTH_SHORT).show()
            }
            progressBar?.setVisibility(View.GONE)
        })

    }

}
