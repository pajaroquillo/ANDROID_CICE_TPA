package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

import android.os.Bundle
import android.os.Handler
import android.support.v7.app.AppCompatActivity
import android.widget.ImageView
import android.widget.TextView
import com.pajaroquillo.teamperformanceapp.R.id.circularView
import kotlinx.android.synthetic.main.activity_myperformance.*
import org.w3c.dom.Text

class MyPerformanceActivity : AppCompatActivity()  {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_myperformance)

        ponerValores()

    }

    fun ponerValores(){
        var txtNombre = findViewById<TextView>(R.id.textname2)
        var txtRole = findViewById<TextView>(R.id.textrole2)
        var imgenusu = findViewById<ImageView>(R.id.imagePer)
        var txtPuntos = findViewById<TextView>(R.id.puntos)
        val userDatabase = DataBaseHelper(this)
        val usuario = userDatabase.readUser(usuarioConectado.USUARIO_CONECTADO)
        txtNombre.text = usuario.get(0).name
        txtRole.text=usuario.get(0).role

        var idimg : Int
        idimg = resources.getIdentifier("com.pajaroquillo.teamperformanceapp:drawable/"+ usuario.get(0).imagen, null,null)
        imgenusu.setImageResource(idimg)

        var evaluacion:Int = 0
        evaluacion = userDatabase.devolverPuntos(usuarioConectado.USUARIO_CONECTADO)
        txtPuntos.text = evaluacion.toString()
        pintarPorentaje(evaluacion)
    }

    fun pintarPorentaje(valor: Int) {
        var i = 1
        val handler = Handler()
        val runnable = object : Runnable {
            override fun run() {
                if (i <= (20*valor)) {
                    handler.postDelayed(this, 5)
                    circularView.setValue(i, valor)
                    i++
                }
            }
        }
        handler.post(runnable)
    }
}