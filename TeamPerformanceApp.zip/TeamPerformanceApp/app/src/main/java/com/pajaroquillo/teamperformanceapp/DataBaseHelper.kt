package com.pajaroquillo.teamperformanceapp

/* 	Creado por:
			Oscar Hernandez Diaz
    Mail:
		  	oscarhdiaz@gmail.com
	Fecha:
		 	Mayo 2018
	Creado para el curso:
			CICE - POV S-145/A/17 CURSO OFICIAL DE PROGRAMACIÓN DE APLICACIONES MÓVILES PARA ANDROID
*/

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

import java.util.ArrayList
import kotlin.math.roundToInt

class DataBaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_ENTRIES)
        db.execSQL(SQL_CREATE_ENTRIES_PERFORMANCE)
        db.execSQL(SQL_INSERT_VALUES_1)
        db.execSQL(SQL_INSERT_VALUES_2)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(SQL_DELETE_ENTRIES)
        db.execSQL(SQL_DELETE_ENTRIES_PERFORMANCE)
        onCreate(db)
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }

    @Throws(SQLiteConstraintException::class)
    fun insertUser(user: UserDB): Boolean {

        val db = writableDatabase

        val values = ContentValues()
        values.put(DataB.UserEntry.COLUMN_USER_ID, user.userid)
        values.put(DataB.UserEntry.COLUMN_NAME, user.name)
        values.put(DataB.UserEntry.COLUMN_MAIL, user.mail)
        values.put(DataB.UserEntry.COLUMN_DIR, user.address)
        values.put(DataB.UserEntry.COLUMN_ROLE, user.role)

        val newRowId = db.insert(DataB.UserEntry.TABLE_NAME, null, values)

        return true
    }

    @Throws(SQLiteConstraintException::class)
    fun deleteUser(userid: String): Boolean {
        val db = writableDatabase
        val selection = DataB.UserEntry.COLUMN_USER_ID + " LIKE ?"
        val selectionArgs = arrayOf(userid)
        db.delete(DataB.UserEntry.TABLE_NAME, selection, selectionArgs)

        return true
    }

    fun teamList(): ArrayList<UserDB> {
        var users = ArrayList<UserDB>()
        users = readAllUsers()

        return users
    }

    fun readUser(userid: String): ArrayList<UserDB> {
        val users = ArrayList<UserDB>()
        val db = writableDatabase
        var cursor: Cursor?=null
        try {
            cursor = db.rawQuery("SELECT * FROM " + DataB.UserEntry.TABLE_NAME + " WHERE " + DataB.UserEntry.COLUMN_USER_ID + "='" + userid + "'", null)
        } catch (e: SQLiteException) {
            db.execSQL(SQL_CREATE_ENTRIES)
            return ArrayList()
        }

        var name: String
        var mail: String
        var address: String
        var role: String
        var imagen:String
        if (cursor!!.moveToFirst()) {
            while (cursor.isAfterLast == false) {
                name = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_NAME))
                mail = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_MAIL))
                address = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_DIR))
                role = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_ROLE))
                imagen = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_IMG))
                users.add(UserDB(userid, name, mail,address,role,imagen))
                cursor.moveToNext()
            }
        }
        return users
    }

    fun readUserByMail(mail: String): String{
        val users = String
        val db = writableDatabase

        var userid: String =""

        var cursor: Cursor?=null
        try {
            cursor = db.rawQuery("SELECT " + DataB.UserEntry.COLUMN_USER_ID + " FROM " + DataB.UserEntry.TABLE_NAME + " WHERE " + DataB.UserEntry.COLUMN_MAIL + "='" + mail + "'", null)
        } catch (e: SQLiteException) {
            // if table not yet present, create it
            db.execSQL(SQL_CREATE_ENTRIES)
            return userid
        }


        if (cursor!!.moveToFirst()) {
            while (cursor.isAfterLast == false) {
                userid = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_USER_ID))
                cursor.moveToNext()
            }
        }
        return userid
    }

    fun readAllUsers(): ArrayList<UserDB> {
        val users = ArrayList<UserDB>()
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("select * from " + DataB.UserEntry.TABLE_NAME, null)
        } catch (e: SQLiteException) {
            db.execSQL(SQL_CREATE_ENTRIES)
            return ArrayList()
        }

        var userid: String
        var name: String
        var mail: String
        var address: String
        var role: String
        var imagen: String
        if (cursor!!.moveToFirst()) {
            while (cursor.isAfterLast == false) {
                userid = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_USER_ID))
                name = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_NAME))
                mail = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_MAIL))
                address = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_DIR))
                role = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_ROLE))
                imagen = cursor.getString(cursor.getColumnIndex(DataB.UserEntry.COLUMN_IMG))
                if (userid != usuarioConectado.USUARIO_CONECTADO) {
                    users.add(UserDB(userid, name, mail, address, role, imagen))
                }
                cursor.moveToNext()
            }
        }
        return users
    }

    fun addUser(name:String, role:String, mail:String, dir:String):String{

        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("select * from " + DataB.UserEntry.TABLE_NAME, null)
        } catch (e: SQLiteException) {
            db.execSQL(SQL_CREATE_ENTRIES)
        }
        val numuser = cursor?.count!! + 1
        val userid = "user" + numuser.toString()

        val SQL_INSERT :String = "INSERT INTO "+ DataB.UserEntry.TABLE_NAME +" (" +
                DataB.UserEntry.COLUMN_USER_ID + ", " +
                DataB.UserEntry.COLUMN_NAME + ", " +
                DataB.UserEntry.COLUMN_MAIL + ", " +
                DataB.UserEntry.COLUMN_DIR + ", " +
                DataB.UserEntry.COLUMN_ROLE + ", " +
                DataB.UserEntry.COLUMN_IMG + ") VALUES ('" +
                userid + "', '" + name + "', '" + mail + "', '"+ dir +"', '" + role + "', 'usu0')"

        db.execSQL(SQL_INSERT)
        return userid
    }
    fun addPerformanceTotal(userid:String){
        val SQL_INSERT_1 = "INSERT INTO performance ( userid, eval, usereva ) " +
                "SELECT users.userid, 0, '"+ userid + "'" +
                " FROM " + DataB.UserEntry.TABLE_NAME +
                " WHERE ((("+ DataB.UserEntry.COLUMN_USER_ID+")<>'"+ userid + "'))"
        val SQL_INSERT_2 = "INSERT INTO performance ( userid, eval, usereva )" +
                " SELECT '" + userid + "',  0, " + DataB.UserEntry.COLUMN_USER_ID +
                " FROM " + DataB.UserEntry.TABLE_NAME +
                " WHERE ((("+ DataB.UserEntry.COLUMN_USER_ID+")<>'"+ userid + "'))"

        val db = writableDatabase
        db.execSQL(SQL_INSERT_1)
        db.execSQL(SQL_INSERT_2)
    }
    companion object {
        val DATABASE_VERSION = 1
        val DATABASE_NAME = "TeamPerformance.db"

        private val SQL_CREATE_ENTRIES =
                "CREATE TABLE " + DataB.UserEntry.TABLE_NAME + " (" +
                        DataB.UserEntry.COLUMN_USER_ID + " TEXT PRIMARY KEY," +
                        DataB.UserEntry.COLUMN_NAME + " TEXT," +
                        DataB.UserEntry.COLUMN_MAIL + " TEXT NOT NULL UNIQUE," +
                        DataB.UserEntry.COLUMN_DIR + " TEXT," +
                        DataB.UserEntry.COLUMN_ROLE + " TEXT," +
                        DataB.UserEntry.COLUMN_IMG + " TEXT)"

        private val SQL_CREATE_ENTRIES_PERFORMANCE = "CREATE TABLE "+ DataB.UserPerformance.TABLE_NAME + " (userid TEXT NOT NULL, usereva TEXT NOT NULL, eval INTEGER, primary key (userid, usereva))"

        private val SQL_INSERT_VALUES_1 = "INSERT INTO users (userid, name, mail, dir, role, imagen) VALUES ('user1','Oscar Hernandez','pajaroquilloCICE@gmail.com','Calle Castilla la Nueva N12','Scrum Master','usu1'), " +
                "('user2','John Smith','prueba6@prueba.com','Rio Turia N12','Process Owner', 'usu2'), " +
                "('user3','Lenny Leonard','prueba2@prueba.com','La Serna','Project Manager', 'usu3'), " +
                "('user4','Profesor Frink','prueba1@prueba.com','Avd De Las Provincias','Scrum Master', 'usu4'), " +
                "('user5','Homer Simpson','prueba3@prueba.com','Fuenlabrada','Project Manager', 'usu5'), " +
                "('user6','Homer Woman','prueba4@prueba.com','Leganes','Scrum Master', 'usu6'), " +
                "('user7','Zapp Brannigan','prueba5@prueba.com','La Serna','Manager', 'usu7')"

        private val SQL_INSERT_VALUES_2 = "INSERT INTO performance (userid, usereva, eval) VALUES ('user1','user2',0)," +
                " ('user1','user3',0)," +
                " ('user1','user4',0)," +
                " ('user2','user1',2)," +
                " ('user2','user3',0)," +
                " ('user2','user4',0)," +
                " ('user3','user1',5)," +
                " ('user3','user2',0)," +
                " ('user3','user4',0)," +
                " ('user4','user1',4)," +
                " ('user4','user2',0)," +
                " ('user4','user3',0)," +
                " ('user1','user5',0)," +
                " ('user1','user6',0)," +
                " ('user1','user7',0)," +
                " ('user2','user5',0)," +
                " ('user2','user6',0)," +
                " ('user2','user7',0)," +
                " ('user3','user5',0)," +
                " ('user3','user6',0)," +
                " ('user3','user7',0)," +
                " ('user4','user5',0)," +
                " ('user4','user6',0)," +
                " ('user4','user7',0)," +
                " ('user5','user1',5)," +
                " ('user5','user2',0)," +
                " ('user5','user4',0)," +
                " ('user5','user3',0)," +
                " ('user5','user6',0)," +
                " ('user5','user7',0)," +
                " ('user6','user1',5)," +
                " ('user6','user2',0)," +
                " ('user6','user4',0)," +
                " ('user6','user3',0)," +
                " ('user6','user5',0)," +
                " ('user6','user7',0)," +
                " ('user7','user1',5)," +
                " ('user7','user2',0)," +
                " ('user7','user4',0)," +
                " ('user7','user3',0)," +
                " ('user7','user5',0)," +
                " ('user7','user6',0) "

        private val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + DataB.UserEntry.TABLE_NAME
        private val SQL_DELETE_ENTRIES_PERFORMANCE = "DROP TABLE IF EXISTS " + DataB.UserPerformance.TABLE_NAME
    }


    //funciones tabla performance
    fun devolverPuntos(userEva: String):Int{
        var punto: Int = 0
        var datos: Int = 0
        val db = writableDatabase
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("select * from " + DataB.UserPerformance.TABLE_NAME + " where " + DataB.UserPerformance.COLUMN_USEREVA + " ='" + userEva +"'" , null)
        } catch (e: SQLiteException) {
            db.execSQL(SQL_CREATE_ENTRIES)
            return 0
        }
        var eva: Int
        if (cursor!!.moveToFirst()) {
            while (cursor.isAfterLast == false) {
                eva = cursor.getInt(cursor.getColumnIndex(DataB.UserPerformance.COLUMN_EVA))
                if (eva>0) {
                    punto = punto + eva
                    datos = datos + 1
                }
                cursor.moveToNext()
            }
        }
        var resultado:Double = 0.0
        if (datos != 0){
            resultado = ((punto/datos).toDouble())
        }
        return resultado.roundToInt()
    }

    fun updatePoints(userid: String, userEva: String, eva: Int): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        val where : String = "userid='"+userid + "' and usereva='"+userEva + "'"

        values.put(DataB.UserPerformance.COLUMN_EVA, eva)

        val updateRowId = db.update(DataB.UserPerformance.TABLE_NAME,values,where,null)

        return true

    }

    @Throws(SQLiteConstraintException::class)
    fun updateUserEva(usereva: UserEva):Boolean{
        val db = writableDatabase
        val values = ContentValues()
        values.put(DataB.UserPerformance.COLUMN_USERID, usereva.userid)
        values.put(DataB.UserPerformance.COLUMN_USEREVA, usereva.userEva)
        values.put(DataB.UserPerformance.COLUMN_EVA, usereva.eva)

        val updateRowId = db.update(DataB.UserPerformance.TABLE_NAME,values,null,null)

        return true
    }
}
